--
-- PostgreSQL database dump
--

-- Dumped from database version 9.6.7
-- Dumped by pg_dump version 9.6.7

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;
SET row_security = off;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public.muni_crrs DROP CONSTRAINT muni_crrs_cod_pen_uc_foreign;
ALTER TABLE ONLY public.msec_ests DROP CONSTRAINT msec_ests_id_master_foreign;
ALTER TABLE ONLY public.msec_ests DROP CONSTRAINT msec_ests_ci_est_tes_foreign;
ALTER TABLE ONLY public.mrol_usus DROP CONSTRAINT mrol_usus_id_tru_foreign;
ALTER TABLE ONLY public.mrol_usus DROP CONSTRAINT mrol_usus_id_rol_tru_foreign;
ALTER TABLE ONLY public.mrol_mods DROP CONSTRAINT mrol_mods_id_rol_trm_foreign;
ALTER TABLE ONLY public.mrol_mods DROP CONSTRAINT mrol_mods_id_mod_trm_foreign;
ALTER TABLE ONLY public.mpuentemasters DROP CONSTRAINT mpuentemasters_id_usu_foreign;
ALTER TABLE ONLY public.mpuentemasters DROP CONSTRAINT mpuentemasters_cod_unidad_foreign;
ALTER TABLE ONLY public.mpuentemasters DROP CONSTRAINT mpuentemasters_cod_seccion_foreign;
ALTER TABLE ONLY public.mplan_evas DROP CONSTRAINT mplan_evas_cod_sec_plan_foreign;
ALTER TABLE ONLY public.mpensums DROP CONSTRAINT mpensums_cod_pnf_p_foreign;
ALTER TABLE ONLY public.mnotas DROP CONSTRAINT mnotas_id_eva_not_foreign;
ALTER TABLE ONLY public.mevaluacions DROP CONSTRAINT mevaluacions_id_plan_eva_foreign;
ALTER TABLE ONLY public.mevaluacions DROP CONSTRAINT mevaluacions_id_inst_eva_foreign;
ALTER TABLE ONLY public.mejes_ucs DROP CONSTRAINT mejes_ucs_cod_uc_pnf_euc_foreign;
ALTER TABLE ONLY public.mejes_ucs DROP CONSTRAINT mejes_ucs_cod_ejes_euc_foreign;
DROP INDEX public.password_resets_token_index;
DROP INDEX public.password_resets_email_index;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_pkey;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_password_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_email_unique;
ALTER TABLE ONLY public.users DROP CONSTRAINT users_ci_usu_unique;
ALTER TABLE ONLY public.muni_crrs DROP CONSTRAINT muni_crrs_pkey;
ALTER TABLE ONLY public.muni_crrs DROP CONSTRAINT muni_crrs_cod_uc_pnf_unique;
ALTER TABLE ONLY public.mseccions DROP CONSTRAINT mseccions_pkey;
ALTER TABLE ONLY public.mseccions DROP CONSTRAINT mseccions_cod_sec_unique;
ALTER TABLE ONLY public.msec_ests DROP CONSTRAINT msec_ests_pkey;
ALTER TABLE ONLY public.mrols DROP CONSTRAINT mrols_pkey;
ALTER TABLE ONLY public.mrols DROP CONSTRAINT mrols_nom_rol_unique;
ALTER TABLE ONLY public.mrols DROP CONSTRAINT mrols_id_rol_unique;
ALTER TABLE ONLY public.mrol_usus DROP CONSTRAINT mrol_usus_pkey;
ALTER TABLE ONLY public.mrol_mods DROP CONSTRAINT mrol_mods_pkey;
ALTER TABLE ONLY public.mrol_mods DROP CONSTRAINT mrol_mods_id_rol_mod_unique;
ALTER TABLE ONLY public.mpuentemasters DROP CONSTRAINT mpuentemasters_pkey;
ALTER TABLE ONLY public.mpuentemasters DROP CONSTRAINT mpuentemasters_id_uc_sec_unique;
ALTER TABLE ONLY public.mpnfs DROP CONSTRAINT mpnfs_pkey;
ALTER TABLE ONLY public.mplan_evas DROP CONSTRAINT mplan_evas_pkey;
ALTER TABLE ONLY public.mpensums DROP CONSTRAINT mpensums_pkey;
ALTER TABLE ONLY public.mnotas DROP CONSTRAINT mnotas_pkey;
ALTER TABLE ONLY public.mmodulos DROP CONSTRAINT mmodulos_pkey;
ALTER TABLE ONLY public.minstrumentos DROP CONSTRAINT minstrumentos_pkey;
ALTER TABLE ONLY public.migrations DROP CONSTRAINT migrations_pkey;
ALTER TABLE ONLY public.mevaluacions DROP CONSTRAINT mevaluacions_pkey;
ALTER TABLE ONLY public.mestudiantes DROP CONSTRAINT mestudiantes_pkey;
ALTER TABLE ONLY public.mestudiantes DROP CONSTRAINT mestudiantes_ci_est_unique;
ALTER TABLE ONLY public.mejes_ucs DROP CONSTRAINT mejes_ucs_pkey;
ALTER TABLE ONLY public.mejes_ucs DROP CONSTRAINT mejes_ucs_cod_uc_ejes_unique;
ALTER TABLE ONLY public.mejes DROP CONSTRAINT mejes_pkey;
ALTER TABLE ONLY public.bitacoras DROP CONSTRAINT bitacoras_pkey;
ALTER TABLE public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.msec_ests ALTER COLUMN id_sec_est DROP DEFAULT;
ALTER TABLE public.mrols ALTER COLUMN id_rol DROP DEFAULT;
ALTER TABLE public.mrol_usus ALTER COLUMN id_rol_usu DROP DEFAULT;
ALTER TABLE public.mrol_mods ALTER COLUMN id_rol_mod DROP DEFAULT;
ALTER TABLE public.mpuentemasters ALTER COLUMN id_uc_sec DROP DEFAULT;
ALTER TABLE public.mpnfs ALTER COLUMN cod_pnf DROP DEFAULT;
ALTER TABLE public.mplan_evas ALTER COLUMN id_plan DROP DEFAULT;
ALTER TABLE public.mpensums ALTER COLUMN cod_pen DROP DEFAULT;
ALTER TABLE public.mnotas ALTER COLUMN id_nota DROP DEFAULT;
ALTER TABLE public.mmodulos ALTER COLUMN id_mod DROP DEFAULT;
ALTER TABLE public.minstrumentos ALTER COLUMN id_inst DROP DEFAULT;
ALTER TABLE public.migrations ALTER COLUMN id DROP DEFAULT;
ALTER TABLE public.mevaluacions ALTER COLUMN id_eva DROP DEFAULT;
ALTER TABLE public.mejes_ucs ALTER COLUMN cod_uc_ejes DROP DEFAULT;
ALTER TABLE public.mejes ALTER COLUMN cod_eje DROP DEFAULT;
ALTER TABLE public.bitacoras ALTER COLUMN id_bitacora DROP DEFAULT;
DROP SEQUENCE public.users_id_seq;
DROP TABLE public.users;
DROP TABLE public.password_resets;
DROP TABLE public.muni_crrs;
DROP TABLE public.mseccions;
DROP SEQUENCE public.msec_ests_id_sec_est_seq;
DROP TABLE public.msec_ests;
DROP SEQUENCE public.mrols_id_rol_seq;
DROP TABLE public.mrols;
DROP SEQUENCE public.mrol_usus_id_rol_usu_seq;
DROP TABLE public.mrol_usus;
DROP SEQUENCE public.mrol_mods_id_rol_mod_seq;
DROP TABLE public.mrol_mods;
DROP SEQUENCE public.mpuentemasters_id_uc_sec_seq;
DROP TABLE public.mpuentemasters;
DROP SEQUENCE public.mpnfs_cod_pnf_seq;
DROP TABLE public.mpnfs;
DROP SEQUENCE public.mplan_evas_id_plan_seq;
DROP TABLE public.mplan_evas;
DROP SEQUENCE public.mpensums_cod_pen_seq;
DROP TABLE public.mpensums;
DROP SEQUENCE public.mnotas_id_nota_seq;
DROP TABLE public.mnotas;
DROP SEQUENCE public.mmodulos_id_mod_seq;
DROP TABLE public.mmodulos;
DROP SEQUENCE public.minstrumentos_id_inst_seq;
DROP TABLE public.minstrumentos;
DROP SEQUENCE public.migrations_id_seq;
DROP TABLE public.migrations;
DROP SEQUENCE public.mevaluacions_id_eva_seq;
DROP TABLE public.mevaluacions;
DROP TABLE public.mestudiantes;
DROP SEQUENCE public.mejes_ucs_cod_uc_ejes_seq;
DROP TABLE public.mejes_ucs;
DROP SEQUENCE public.mejes_cod_eje_seq;
DROP TABLE public.mejes;
DROP SEQUENCE public.bitacoras_id_bitacora_seq;
DROP TABLE public.bitacoras;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: bitacoras; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE bitacoras (
    id_bitacora integer NOT NULL,
    nombre character varying(255) NOT NULL,
    id_usuario character varying(255) NOT NULL,
    accion character varying(255) NOT NULL,
    "observación" character varying(255) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE bitacoras OWNER TO postgres;

--
-- Name: bitacoras_id_bitacora_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE bitacoras_id_bitacora_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE bitacoras_id_bitacora_seq OWNER TO postgres;

--
-- Name: bitacoras_id_bitacora_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE bitacoras_id_bitacora_seq OWNED BY bitacoras.id_bitacora;


--
-- Name: mejes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mejes (
    cod_eje integer NOT NULL,
    nom_eje character varying(20) NOT NULL,
    descripcion text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mejes OWNER TO postgres;

--
-- Name: mejes_cod_eje_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mejes_cod_eje_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mejes_cod_eje_seq OWNER TO postgres;

--
-- Name: mejes_cod_eje_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mejes_cod_eje_seq OWNED BY mejes.cod_eje;


--
-- Name: mejes_ucs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mejes_ucs (
    cod_uc_ejes integer NOT NULL,
    cod_uc_pnf_euc character varying(9) NOT NULL,
    cod_ejes_euc integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mejes_ucs OWNER TO postgres;

--
-- Name: mejes_ucs_cod_uc_ejes_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mejes_ucs_cod_uc_ejes_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mejes_ucs_cod_uc_ejes_seq OWNER TO postgres;

--
-- Name: mejes_ucs_cod_uc_ejes_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mejes_ucs_cod_uc_ejes_seq OWNED BY mejes_ucs.cod_uc_ejes;


--
-- Name: mestudiantes; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mestudiantes (
    ci_est character varying(9) NOT NULL,
    nom_est character varying(30) NOT NULL,
    ape_est character varying(30) NOT NULL,
    cod_pnf_est character varying(6) NOT NULL,
    email character varying(36) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mestudiantes OWNER TO postgres;

--
-- Name: mevaluacions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mevaluacions (
    id_eva integer NOT NULL,
    unidad integer NOT NULL,
    id_plan_eva integer NOT NULL,
    id_inst_eva integer NOT NULL,
    criterio text NOT NULL,
    tecnica character varying(25) NOT NULL,
    observacion text,
    fec_prop date NOT NULL,
    fec_res date,
    participacion character varying(3),
    ponderacion double precision NOT NULL,
    fec_part date,
    corte character varying(255) NOT NULL,
    contenido text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mevaluacions OWNER TO postgres;

--
-- Name: mevaluacions_id_eva_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mevaluacions_id_eva_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mevaluacions_id_eva_seq OWNER TO postgres;

--
-- Name: mevaluacions_id_eva_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mevaluacions_id_eva_seq OWNED BY mevaluacions.id_eva;


--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE migrations (
    id integer NOT NULL,
    migration character varying(255) NOT NULL,
    batch integer NOT NULL
);


ALTER TABLE migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE migrations_id_seq OWNED BY migrations.id;


--
-- Name: minstrumentos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE minstrumentos (
    id_inst integer NOT NULL,
    tip_inst character varying(35) NOT NULL,
    descp_inst text NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE minstrumentos OWNER TO postgres;

--
-- Name: minstrumentos_id_inst_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE minstrumentos_id_inst_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE minstrumentos_id_inst_seq OWNER TO postgres;

--
-- Name: minstrumentos_id_inst_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE minstrumentos_id_inst_seq OWNED BY minstrumentos.id_inst;


--
-- Name: mmodulos; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mmodulos (
    id_mod integer NOT NULL,
    nom_mod character varying(25) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mmodulos OWNER TO postgres;

--
-- Name: mmodulos_id_mod_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mmodulos_id_mod_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mmodulos_id_mod_seq OWNER TO postgres;

--
-- Name: mmodulos_id_mod_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mmodulos_id_mod_seq OWNED BY mmodulos.id_mod;


--
-- Name: mnotas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mnotas (
    id_nota integer NOT NULL,
    id_eva_not integer NOT NULL,
    ci_est_not character varying(9) NOT NULL,
    nota double precision NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mnotas OWNER TO postgres;

--
-- Name: mnotas_id_nota_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mnotas_id_nota_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mnotas_id_nota_seq OWNER TO postgres;

--
-- Name: mnotas_id_nota_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mnotas_id_nota_seq OWNED BY mnotas.id_nota;


--
-- Name: mpensums; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mpensums (
    cod_pen integer NOT NULL,
    cod_pnf_p integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mpensums OWNER TO postgres;

--
-- Name: mpensums_cod_pen_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mpensums_cod_pen_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mpensums_cod_pen_seq OWNER TO postgres;

--
-- Name: mpensums_cod_pen_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mpensums_cod_pen_seq OWNED BY mpensums.cod_pen;


--
-- Name: mplan_evas; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mplan_evas (
    id_plan integer NOT NULL,
    status character varying(10) NOT NULL,
    cod_sec_plan integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mplan_evas OWNER TO postgres;

--
-- Name: mplan_evas_id_plan_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mplan_evas_id_plan_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mplan_evas_id_plan_seq OWNER TO postgres;

--
-- Name: mplan_evas_id_plan_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mplan_evas_id_plan_seq OWNED BY mplan_evas.id_plan;


--
-- Name: mpnfs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mpnfs (
    cod_pnf integer NOT NULL,
    nom_pnf character varying(30) NOT NULL,
    cant_secc integer NOT NULL,
    cant_uni integer NOT NULL,
    tiempo_respaldo integer NOT NULL,
    fecha_final date NOT NULL,
    enabled boolean DEFAULT false NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mpnfs OWNER TO postgres;

--
-- Name: mpnfs_cod_pnf_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mpnfs_cod_pnf_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mpnfs_cod_pnf_seq OWNER TO postgres;

--
-- Name: mpnfs_cod_pnf_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mpnfs_cod_pnf_seq OWNED BY mpnfs.cod_pnf;


--
-- Name: mpuentemasters; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mpuentemasters (
    id_uc_sec integer NOT NULL,
    cod_unidad character varying(9) NOT NULL,
    id_usu integer NOT NULL,
    cod_seccion character varying(255) NOT NULL,
    coordinador boolean NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mpuentemasters OWNER TO postgres;

--
-- Name: mpuentemasters_id_uc_sec_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mpuentemasters_id_uc_sec_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mpuentemasters_id_uc_sec_seq OWNER TO postgres;

--
-- Name: mpuentemasters_id_uc_sec_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mpuentemasters_id_uc_sec_seq OWNED BY mpuentemasters.id_uc_sec;


--
-- Name: mrol_mods; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mrol_mods (
    id_rol_mod integer NOT NULL,
    id_rol_trm integer NOT NULL,
    id_mod_trm integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mrol_mods OWNER TO postgres;

--
-- Name: mrol_mods_id_rol_mod_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mrol_mods_id_rol_mod_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mrol_mods_id_rol_mod_seq OWNER TO postgres;

--
-- Name: mrol_mods_id_rol_mod_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mrol_mods_id_rol_mod_seq OWNED BY mrol_mods.id_rol_mod;


--
-- Name: mrol_usus; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mrol_usus (
    id_rol_usu integer NOT NULL,
    id_tru integer NOT NULL,
    id_rol_tru integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mrol_usus OWNER TO postgres;

--
-- Name: mrol_usus_id_rol_usu_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mrol_usus_id_rol_usu_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mrol_usus_id_rol_usu_seq OWNER TO postgres;

--
-- Name: mrol_usus_id_rol_usu_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mrol_usus_id_rol_usu_seq OWNED BY mrol_usus.id_rol_usu;


--
-- Name: mrols; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mrols (
    id_rol integer NOT NULL,
    nom_rol character varying(35) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mrols OWNER TO postgres;

--
-- Name: mrols_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE mrols_id_rol_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE mrols_id_rol_seq OWNER TO postgres;

--
-- Name: mrols_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE mrols_id_rol_seq OWNED BY mrols.id_rol;


--
-- Name: msec_ests; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE msec_ests (
    id_sec_est integer NOT NULL,
    id_master integer NOT NULL,
    ci_est_tes character varying(9) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE msec_ests OWNER TO postgres;

--
-- Name: msec_ests_id_sec_est_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE msec_ests_id_sec_est_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE msec_ests_id_sec_est_seq OWNER TO postgres;

--
-- Name: msec_ests_id_sec_est_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE msec_ests_id_sec_est_seq OWNED BY msec_ests.id_sec_est;


--
-- Name: mseccions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE mseccions (
    cod_sec character varying(6) NOT NULL,
    turno character varying(8) NOT NULL,
    trayecto character varying(1) NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE mseccions OWNER TO postgres;

--
-- Name: muni_crrs; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE muni_crrs (
    cod_uc_pnf character varying(9) NOT NULL,
    cod_uc_nac character varying(9) NOT NULL,
    creditos integer NOT NULL,
    nom_uc character varying(30) NOT NULL,
    trayecto character varying(1) NOT NULL,
    hta double precision NOT NULL,
    htt double precision NOT NULL,
    hte double precision NOT NULL,
    periodo boolean NOT NULL,
    cod_pen_uc integer NOT NULL,
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE muni_crrs OWNER TO postgres;

--
-- Name: password_resets; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE password_resets (
    email character varying(255) NOT NULL,
    token character varying(255) NOT NULL,
    created_at timestamp(0) without time zone
);


ALTER TABLE password_resets OWNER TO postgres;

--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE users (
    id integer NOT NULL,
    ci_usu character varying(9) NOT NULL,
    name character varying(15) NOT NULL,
    ape_usu character varying(15) NOT NULL,
    img_perfil character varying(255) NOT NULL,
    email character varying(36) NOT NULL,
    password character varying(256) NOT NULL,
    tlf character varying(12) NOT NULL,
    status boolean DEFAULT false NOT NULL,
    remember_token character varying(100),
    created_at timestamp(0) without time zone,
    updated_at timestamp(0) without time zone
);


ALTER TABLE users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE users_id_seq OWNED BY users.id;


--
-- Name: bitacoras id_bitacora; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY bitacoras ALTER COLUMN id_bitacora SET DEFAULT nextval('bitacoras_id_bitacora_seq'::regclass);


--
-- Name: mejes cod_eje; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mejes ALTER COLUMN cod_eje SET DEFAULT nextval('mejes_cod_eje_seq'::regclass);


--
-- Name: mejes_ucs cod_uc_ejes; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mejes_ucs ALTER COLUMN cod_uc_ejes SET DEFAULT nextval('mejes_ucs_cod_uc_ejes_seq'::regclass);


--
-- Name: mevaluacions id_eva; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mevaluacions ALTER COLUMN id_eva SET DEFAULT nextval('mevaluacions_id_eva_seq'::regclass);


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY migrations ALTER COLUMN id SET DEFAULT nextval('migrations_id_seq'::regclass);


--
-- Name: minstrumentos id_inst; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY minstrumentos ALTER COLUMN id_inst SET DEFAULT nextval('minstrumentos_id_inst_seq'::regclass);


--
-- Name: mmodulos id_mod; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mmodulos ALTER COLUMN id_mod SET DEFAULT nextval('mmodulos_id_mod_seq'::regclass);


--
-- Name: mnotas id_nota; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mnotas ALTER COLUMN id_nota SET DEFAULT nextval('mnotas_id_nota_seq'::regclass);


--
-- Name: mpensums cod_pen; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpensums ALTER COLUMN cod_pen SET DEFAULT nextval('mpensums_cod_pen_seq'::regclass);


--
-- Name: mplan_evas id_plan; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mplan_evas ALTER COLUMN id_plan SET DEFAULT nextval('mplan_evas_id_plan_seq'::regclass);


--
-- Name: mpnfs cod_pnf; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpnfs ALTER COLUMN cod_pnf SET DEFAULT nextval('mpnfs_cod_pnf_seq'::regclass);


--
-- Name: mpuentemasters id_uc_sec; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpuentemasters ALTER COLUMN id_uc_sec SET DEFAULT nextval('mpuentemasters_id_uc_sec_seq'::regclass);


--
-- Name: mrol_mods id_rol_mod; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_mods ALTER COLUMN id_rol_mod SET DEFAULT nextval('mrol_mods_id_rol_mod_seq'::regclass);


--
-- Name: mrol_usus id_rol_usu; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_usus ALTER COLUMN id_rol_usu SET DEFAULT nextval('mrol_usus_id_rol_usu_seq'::regclass);


--
-- Name: mrols id_rol; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrols ALTER COLUMN id_rol SET DEFAULT nextval('mrols_id_rol_seq'::regclass);


--
-- Name: msec_ests id_sec_est; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY msec_ests ALTER COLUMN id_sec_est SET DEFAULT nextval('msec_ests_id_sec_est_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users ALTER COLUMN id SET DEFAULT nextval('users_id_seq'::regclass);


--
-- Data for Name: bitacoras; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY bitacoras (id_bitacora, nombre, id_usuario, accion, "observación", created_at, updated_at) FROM stdin;
1	ganeshadevteam |	00000420	modificar.usuario	Se ha Editado al docente: ganeshadevteam | 	2018-05-29 12:40:36	2018-05-29 12:40:36
2	ganeshadevteam puta	00000420	crear.ejes	Nuevo Eje Registrado: logico	2018-05-29 12:42:50	2018-05-29 12:42:50
3	ganeshadevteam puta	00000420	crear.uc	Unidad Curricular Creada: MATEMATICA 1	2018-05-29 12:43:48	2018-05-29 12:43:48
4	ganeshadevteam puta	00000420	crear.uc	Unidad Curricular Creada: PROGRAMACION 1	2018-05-29 12:44:28	2018-05-29 12:44:28
5	ganeshadevteam puta	00000420	crear.uc	Unidad Curricular Creada: PROGRAMACION 2	2018-05-29 12:45:00	2018-05-29 12:45:00
6	ganeshadevteam puta	00000420	crear.uc	Unidad Curricular Creada: MODELADO DE BD	2018-05-29 12:45:40	2018-05-29 12:45:40
7	ganeshadevteam puta	00000420	crear.uc	Unidad Curricular Creada: AUDITORIA	2018-05-29 12:46:13	2018-05-29 12:46:13
8	ganeshadevteam puta	00000420	crear.seccion	Seccion Creada: IN0001	2018-05-29 12:46:32	2018-05-29 12:46:32
9	ganeshadevteam puta	00000420	crear.seccion	Seccion Creada: IN1111	2018-05-29 12:46:43	2018-05-29 12:46:43
10	ganeshadevteam puta	00000420	crear.seccion	Seccion Creada: IN2222	2018-05-29 12:46:58	2018-05-29 12:46:58
11	ganeshadevteam puta	00000420	eliminar.seccion	Seccion Eliminada: IN1111	2018-05-29 12:47:05	2018-05-29 12:47:05
12	ganeshadevteam puta	00000420	crear.seccion	Seccion Creada: IN2222	2018-05-29 12:47:19	2018-05-29 12:47:19
13	ganeshadevteam puta	00000420	crear.seccion	Seccion Creada: IN1111	2018-05-29 12:47:39	2018-05-29 12:47:39
14	ganeshadevteam puta	00000420	crear.seccion	Seccion Creada: IN3121	2018-05-29 12:47:53	2018-05-29 12:47:53
15	ganeshadevteam puta	00000420	crear.seccion	Seccion Creada: IN4121	2018-05-29 12:48:03	2018-05-29 12:48:03
16	ganeshadevteam puta	00000420	crear.usuario	Se ha creado un nuevo docente: admin tester 	2018-05-29 12:49:58	2018-05-29 12:49:58
17	ganeshadevteam puta	00000420	asignar.uc	Nueva Docente para la Unidad/Seccion:MAT11/IN0001 responsable: admin tester 	2018-05-29 12:52:34	2018-05-29 12:52:34
18	ganeshadevteam puta	00000420	asignar.uc	Nueva Docente para la Unidad/Seccion:PROG111/IN1111 responsable: admin tester 	2018-05-29 12:52:46	2018-05-29 12:52:46
19	ganeshadevteam puta	00000420	asignar.uc	Nueva Docente para la Unidad/Seccion:AUDIT44/IN4121 responsable: admin tester 	2018-05-29 12:53:06	2018-05-29 12:53:06
20	admin tester	00000000	crear.planmaster	PLan Creado con exito para la unidad: MAT11	2018-05-29 12:56:42	2018-05-29 12:56:42
21	admin tester	00000000	modificar.usuario	Se ha Editado al docente: admin tester 	2018-05-29 12:59:42	2018-05-29 12:59:42
22	admin tester	00000000	subir.listado	alumno registrado: josejose	2018-05-29 13:01:02	2018-05-29 13:01:02
23	admin tester	00000000	subir.listado	alumno registrado: grisaldagrisalda	2018-05-29 13:01:02	2018-05-29 13:01:02
24	admin tester	00000000	subir.listado	alumno registrado: josefinajosefina	2018-05-29 13:01:02	2018-05-29 13:01:02
25	admin tester	00000000	subir.listado	alumno registrado: merkjosemerkjose	2018-05-29 13:01:02	2018-05-29 13:01:02
26	admin tester	00000000	subir.listado	alumno registrado: josdsdseitojosdsdseito	2018-05-29 13:01:02	2018-05-29 13:01:02
27	admin tester	00000000	modificar.listado	alumno actualizado: josejose	2018-05-29 13:01:14	2018-05-29 13:01:14
28	admin tester	00000000	modificar.listado	alumno actualizado: grisaldagrisalda	2018-05-29 13:01:15	2018-05-29 13:01:15
29	admin tester	00000000	modificar.listado	alumno actualizado: josefinajosefina	2018-05-29 13:01:15	2018-05-29 13:01:15
30	admin tester	00000000	modificar.listado	alumno actualizado: merkjosemerkjose	2018-05-29 13:01:15	2018-05-29 13:01:15
31	admin tester	00000000	modificar.listado	alumno actualizado: josdsdseitojosdsdseito	2018-05-29 13:01:15	2018-05-29 13:01:15
32	admin tester	00000000	asignar.planhijo	Asignación con exito para la unidad: MAT11  seccion: IN0001	2018-05-29 13:02:01	2018-05-29 13:02:01
33	admin tester	00000000	crear.planmaster	PLan Creado con exito para la unidad: AUDIT44	2018-05-29 13:05:12	2018-05-29 13:05:12
34	admin tester	00000000	asignar.planhijo	Asignación con exito para la unidad: AUDIT44  seccion: IN4121	2018-05-29 13:05:19	2018-05-29 13:05:19
35	admin tester	00000000	asignar.planhijo	Plan hijo Impreso ["AUDIT44"]	2018-05-29 13:06:26	2018-05-29 13:06:26
36	admin tester	00000000	asignar.planhijo	Plan hijo Impreso ["AUDIT44"]	2018-05-29 13:11:30	2018-05-29 13:11:30
37	admin tester	00000000	asignar.planhijo	Plan hijo Impreso ["AUDIT44"]	2018-05-29 13:12:05	2018-05-29 13:12:05
38	admin tester	00000000	asignar.planhijo	Plan hijo Impreso ["AUDIT44"]	2018-05-29 13:13:54	2018-05-29 13:13:54
39	admin tester	00000000	asignar.planhijo	Plan hijo Impreso ["AUDIT44"]	2018-05-29 13:15:57	2018-05-29 13:15:57
40	admin tester	00000000	crear.usuario	Se ha creado un nuevo docente: Enyer Freitez 	2018-05-29 13:30:40	2018-05-29 13:30:40
41	admin tester	00000000	asignar.planhijo	Plan hijo Impreso ["MAT11"]	2018-05-29 17:12:41	2018-05-29 17:12:41
42	admin tester	00000000	asignar.planhijo	Plan hijo Impreso ["MAT11"]	2018-05-29 17:13:48	2018-05-29 17:13:48
\.


--
-- Name: bitacoras_id_bitacora_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('bitacoras_id_bitacora_seq', 42, true);


--
-- Data for Name: mejes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mejes (cod_eje, nom_eje, descripcion, created_at, updated_at) FROM stdin;
1	Estetico Ludico	Descripcion del Ludico	2018-05-29 12:40:17	2018-05-29 12:40:17
2	logico	logica	2018-05-29 12:42:49	2018-05-29 12:42:49
\.


--
-- Name: mejes_cod_eje_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mejes_cod_eje_seq', 2, true);


--
-- Data for Name: mejes_ucs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mejes_ucs (cod_uc_ejes, cod_uc_pnf_euc, cod_ejes_euc, created_at, updated_at) FROM stdin;
1	MAT11	2	\N	\N
2	PROG111	2	\N	\N
3	PROG22	2	\N	\N
4	MOD22	1	\N	\N
5	MOD22	2	\N	\N
6	AUDIT44	2	\N	\N
\.


--
-- Name: mejes_ucs_cod_uc_ejes_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mejes_ucs_cod_uc_ejes_seq', 6, true);


--
-- Data for Name: mestudiantes; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mestudiantes (ci_est, nom_est, ape_est, cod_pnf_est, email, created_at, updated_at) FROM stdin;
2222222	jose	perez	1	jesusjclark@gmail.com	\N	\N
3333111	grisalda	perez	1	enyerfreitez@gmail.com	\N	\N
24333111	josefina	perez	1	ganeshadevteam@gmail.com	\N	\N
25333111	merkjose	perez	1	vainaconvaina@h.com	\N	\N
26333111	josdsdseito	perez	1	ganehsa@correo.com	\N	\N
\.


--
-- Data for Name: mevaluacions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mevaluacions (id_eva, unidad, id_plan_eva, id_inst_eva, criterio, tecnica, observacion, fec_prop, fec_res, participacion, ponderacion, fec_part, corte, contenido, created_at, updated_at) FROM stdin;
1	1	1	1	conocimientos básicoa	analisis	Agregar Observacion	2018-05-30	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	fracciones y logica	2018-05-29 12:56:42	2018-05-29 12:56:42
2	2	1	2	manejo del tema	observacion	Agregar Observacion	2018-05-31	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	mcm variables	2018-05-29 12:56:42	2018-05-29 12:56:42
3	1	2	1	conocimientos básicoa	analisis	Agregar Observacion	2018-05-30	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	fracciones y logica	2018-05-29 13:02:02	2018-05-29 13:02:02
4	2	2	2	manejo del tema	observacion	Agregar Observacion	2018-05-31	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	mcm variables	2018-05-29 13:02:02	2018-05-29 13:02:02
5	1	3	1	manejo del tema\r\ninvestigacion	analisis	Agregar Observacion	2018-05-30	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	investigacion de auditor	2018-05-29 13:05:12	2018-05-29 13:05:12
6	2	3	2	manejo del tema\r\ninvestigacion	observacion	Agregar Observacion	2018-05-31	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	diagnosticos	2018-05-29 13:05:12	2018-05-29 13:05:12
7	1	4	1	manejo del tema\r\ninvestigacion	analisis	Agregar Observacion	2018-05-30	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	investigacion de auditor	2018-05-29 13:05:19	2018-05-29 13:05:19
8	2	4	2	manejo del tema\r\ninvestigacion	observacion	Agregar Observacion	2018-05-31	2000-01-01	\N	5	2000-01-01	SIN ASIGNAR	diagnosticos	2018-05-29 13:05:19	2018-05-29 13:05:19
\.


--
-- Name: mevaluacions_id_eva_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mevaluacions_id_eva_seq', 8, true);


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY migrations (id, migration, batch) FROM stdin;
1	2014_10_12_000000_create_users_table	1
2	2014_10_12_100000_create_password_resets_table	1
3	2017_03_07_140226_create_mpnfs_table	1
4	2017_03_07_140243_create_mpensums_table	1
5	2017_03_07_140325_create_muni_crrs_table	1
6	2017_03_07_140429_create_mejes_table	1
7	2017_03_07_140440_create_mejes_ucs_table	1
8	2017_03_07_140451_create_mseccions_table	1
9	2017_03_07_140462_mpuentemaster	1
10	2017_03_07_140516_create_mestudiantes_table	1
11	2017_03_07_140520_create_msec_ests_table	1
12	2017_03_07_140530_create_mplan_evas_table	1
13	2017_03_07_140614_create_minstrumentos_table	1
14	2017_03_07_140620_create_mevaluacions_table	1
15	2017_03_07_140624_create_mnotas_table	1
16	2017_03_07_140721_create_mrols_table	1
17	2017_03_07_140725_create_mrol_usus_table	1
18	2017_03_07_140755_create_mmodulos_table	1
19	2017_03_07_140805_create_mrol_mods_table	1
20	2017_05_20_234721_Bitacoras	1
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('migrations_id_seq', 20, true);


--
-- Data for Name: minstrumentos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY minstrumentos (id_inst, tip_inst, descp_inst, created_at, updated_at) FROM stdin;
1	Examen	Evaluación Individual	2018-05-29 12:40:19	2018-05-29 12:40:19
2	Taller	Evaluación Grupal	2018-05-29 12:40:19	2018-05-29 12:40:19
\.


--
-- Name: minstrumentos_id_inst_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('minstrumentos_id_inst_seq', 2, true);


--
-- Data for Name: mmodulos; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mmodulos (id_mod, nom_mod, created_at, updated_at) FROM stdin;
1	crear.usuario	2018-05-29 12:40:17	2018-05-29 12:40:17
2	eliminar.usuario	2018-05-29 12:40:17	2018-05-29 12:40:17
3	modificar.usuario	2018-05-29 12:40:17	2018-05-29 12:40:17
4	asignar.usuario	2018-05-29 12:40:17	2018-05-29 12:40:17
5	consultar.usuario	2018-05-29 12:40:17	2018-05-29 12:40:17
6	checkprivatepass.usuario	2018-05-29 12:40:17	2018-05-29 12:40:17
7	checkpublicpass.usuario	2018-05-29 12:40:17	2018-05-29 12:40:17
8	crear.rol	2018-05-29 12:40:17	2018-05-29 12:40:17
9	eliminar.rol	2018-05-29 12:40:17	2018-05-29 12:40:17
10	modificar.rol	2018-05-29 12:40:17	2018-05-29 12:40:17
11	consultar.rol	2018-05-29 12:40:17	2018-05-29 12:40:17
12	crear.ejes	2018-05-29 12:40:17	2018-05-29 12:40:17
13	eliminar.ejes	2018-05-29 12:40:17	2018-05-29 12:40:17
14	modificar.ejes	2018-05-29 12:40:17	2018-05-29 12:40:17
15	crear.instrumentos	2018-05-29 12:40:17	2018-05-29 12:40:17
16	eliminar.instrumentos	2018-05-29 12:40:17	2018-05-29 12:40:17
17	modificar.instrumentos	2018-05-29 12:40:17	2018-05-29 12:40:17
18	crear.uc	2018-05-29 12:40:17	2018-05-29 12:40:17
19	consultar.uc	2018-05-29 12:40:17	2018-05-29 12:40:17
20	eliminar.uc	2018-05-29 12:40:17	2018-05-29 12:40:17
21	modificar.uc	2018-05-29 12:40:17	2018-05-29 12:40:17
22	crear.planmaestro	2018-05-29 12:40:17	2018-05-29 12:40:17
23	eliminar.plan	2018-05-29 12:40:17	2018-05-29 12:40:17
24	modificar.planmaestro	2018-05-29 12:40:17	2018-05-29 12:40:17
25	modificar.planhijo	2018-05-29 12:40:17	2018-05-29 12:40:17
26	asignar.planhijo	2018-05-29 12:40:17	2018-05-29 12:40:17
27	imprimir.plan	2018-05-29 12:40:17	2018-05-29 12:40:17
28	consultar.planes	2018-05-29 12:40:17	2018-05-29 12:40:17
29	subir.listado	2018-05-29 12:40:17	2018-05-29 12:40:17
30	eliminar.alumno	2018-05-29 12:40:17	2018-05-29 12:40:17
31	agregar.alumnomanual	2018-05-29 12:40:17	2018-05-29 12:40:17
32	modificar.alumnomanual	2018-05-29 12:40:17	2018-05-29 12:40:17
33	modificar.listado	2018-05-29 12:40:17	2018-05-29 12:40:17
34	consultar.alumno	2018-05-29 12:40:17	2018-05-29 12:40:17
35	crear.seccion	2018-05-29 12:40:17	2018-05-29 12:40:17
36	eliminar.seccion	2018-05-29 12:40:17	2018-05-29 12:40:17
37	modificar.seccion	2018-05-29 12:40:17	2018-05-29 12:40:17
38	asignar.nota	2018-05-29 12:40:17	2018-05-29 12:40:17
39	transcribir.nota	2018-05-29 12:40:17	2018-05-29 12:40:17
40	modificar.nota	2018-05-29 12:40:17	2018-05-29 12:40:17
41	publicar.nota	2018-05-29 12:40:17	2018-05-29 12:40:17
42	consultar.nota	2018-05-29 12:40:17	2018-05-29 12:40:17
43	consulta.aprobados	2018-05-29 12:40:17	2018-05-29 12:40:17
44	consulta.secciones	2018-05-29 12:40:17	2018-05-29 12:40:17
45	consulta.per	2018-05-29 12:40:17	2018-05-29 12:40:17
\.


--
-- Name: mmodulos_id_mod_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mmodulos_id_mod_seq', 45, true);


--
-- Data for Name: mnotas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mnotas (id_nota, id_eva_not, ci_est_not, nota, created_at, updated_at) FROM stdin;
\.


--
-- Name: mnotas_id_nota_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mnotas_id_nota_seq', 1, false);


--
-- Data for Name: mpensums; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mpensums (cod_pen, cod_pnf_p, created_at, updated_at) FROM stdin;
1	1	2018-05-29 12:40:17	2018-05-29 12:40:17
\.


--
-- Name: mpensums_cod_pen_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mpensums_cod_pen_seq', 1, true);


--
-- Data for Name: mplan_evas; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mplan_evas (id_plan, status, cod_sec_plan, created_at, updated_at) FROM stdin;
1	MASTER	8	2018-05-29 12:56:42	2018-05-29 12:56:42
2	ASIGNADO	1	2018-05-29 13:02:01	2018-05-29 13:02:01
3	MASTER	9	2018-05-29 13:05:12	2018-05-29 13:05:12
4	ASIGNADO	7	2018-05-29 13:05:19	2018-05-29 13:05:19
\.


--
-- Name: mplan_evas_id_plan_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mplan_evas_id_plan_seq', 4, true);


--
-- Data for Name: mpnfs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mpnfs (cod_pnf, nom_pnf, cant_secc, cant_uni, tiempo_respaldo, fecha_final, enabled, created_at, updated_at) FROM stdin;
1	PNF INFORMATICA	6	5	3	2019-10-21	t	2018-05-29 12:40:17	2018-05-29 12:41:05
\.


--
-- Name: mpnfs_cod_pnf_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mpnfs_cod_pnf_seq', 1, false);


--
-- Data for Name: mpuentemasters; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mpuentemasters (id_uc_sec, cod_unidad, id_usu, cod_seccion, coordinador, created_at, updated_at) FROM stdin;
3	PROG22	2	IN2222	f	\N	\N
4	PROG22	2	IN2222	f	\N	\N
6	MOD22	2	IN3121	f	\N	\N
8	MAT11	4	NULL	t	\N	\N
9	AUDIT44	4	NULL	t	\N	\N
1	MAT11	4	IN0001	f	\N	\N
5	PROG111	4	IN1111	f	\N	\N
7	AUDIT44	4	IN4121	f	\N	\N
\.


--
-- Name: mpuentemasters_id_uc_sec_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mpuentemasters_id_uc_sec_seq', 9, true);


--
-- Data for Name: mrol_mods; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mrol_mods (id_rol_mod, id_rol_trm, id_mod_trm, created_at, updated_at) FROM stdin;
1	1	42	\N	\N
2	1	38	\N	\N
3	1	39	\N	\N
4	1	40	\N	\N
5	1	41	\N	\N
6	1	6	\N	\N
7	1	7	\N	\N
8	1	43	\N	\N
9	1	44	\N	\N
10	1	45	\N	\N
11	1	34	\N	\N
12	1	29	\N	\N
13	1	30	\N	\N
14	1	31	\N	\N
15	1	32	\N	\N
16	1	33	\N	\N
17	1	35	\N	\N
18	1	36	\N	\N
19	1	37	\N	\N
20	1	18	\N	\N
21	1	19	\N	\N
22	1	20	\N	\N
23	1	21	\N	\N
24	1	28	\N	\N
25	1	22	\N	\N
26	1	23	\N	\N
27	1	24	\N	\N
28	1	25	\N	\N
29	1	26	\N	\N
30	1	27	\N	\N
31	1	10	\N	\N
32	1	12	\N	\N
33	1	13	\N	\N
34	1	14	\N	\N
35	1	15	\N	\N
36	1	16	\N	\N
37	1	17	\N	\N
38	1	5	\N	\N
39	1	1	\N	\N
40	1	2	\N	\N
41	1	3	\N	\N
42	1	4	\N	\N
43	1	11	\N	\N
44	1	8	\N	\N
45	1	9	\N	\N
46	2	42	\N	\N
47	2	38	\N	\N
48	2	39	\N	\N
49	2	40	\N	\N
50	2	41	\N	\N
51	2	6	\N	\N
52	2	7	\N	\N
53	2	43	\N	\N
54	2	44	\N	\N
55	2	45	\N	\N
56	2	34	\N	\N
57	2	29	\N	\N
58	2	30	\N	\N
59	2	31	\N	\N
60	2	32	\N	\N
61	2	33	\N	\N
62	2	35	\N	\N
63	2	36	\N	\N
64	2	37	\N	\N
65	2	18	\N	\N
66	2	19	\N	\N
67	2	20	\N	\N
68	2	21	\N	\N
69	2	28	\N	\N
70	2	22	\N	\N
71	2	23	\N	\N
72	2	24	\N	\N
73	2	25	\N	\N
74	2	26	\N	\N
75	2	27	\N	\N
76	2	10	\N	\N
77	2	12	\N	\N
78	2	13	\N	\N
79	2	14	\N	\N
80	2	15	\N	\N
81	2	16	\N	\N
82	2	17	\N	\N
83	2	5	\N	\N
84	2	1	\N	\N
85	2	2	\N	\N
86	2	3	\N	\N
87	2	4	\N	\N
88	2	11	\N	\N
89	2	8	\N	\N
90	2	9	\N	\N
91	3	43	\N	\N
92	3	44	\N	\N
93	3	45	\N	\N
94	3	35	\N	\N
95	3	37	\N	\N
96	3	18	\N	\N
97	3	19	\N	\N
98	3	21	\N	\N
99	3	12	\N	\N
100	3	14	\N	\N
101	3	15	\N	\N
102	3	17	\N	\N
103	3	1	\N	\N
104	3	5	\N	\N
105	3	3	\N	\N
106	4	38	\N	\N
107	4	39	\N	\N
108	4	40	\N	\N
109	4	41	\N	\N
110	4	42	\N	\N
111	4	6	\N	\N
112	4	7	\N	\N
113	4	43	\N	\N
114	4	44	\N	\N
115	4	45	\N	\N
116	4	29	\N	\N
117	4	30	\N	\N
118	4	31	\N	\N
119	4	32	\N	\N
120	4	33	\N	\N
121	4	34	\N	\N
122	4	19	\N	\N
123	4	28	\N	\N
124	4	25	\N	\N
125	4	27	\N	\N
126	4	15	\N	\N
127	4	17	\N	\N
128	4	11	\N	\N
129	5	42	\N	\N
130	5	6	\N	\N
131	5	7	\N	\N
132	5	43	\N	\N
133	5	44	\N	\N
134	5	45	\N	\N
135	5	34	\N	\N
136	5	19	\N	\N
137	5	28	\N	\N
138	5	22	\N	\N
139	5	23	\N	\N
140	5	24	\N	\N
141	5	27	\N	\N
142	5	15	\N	\N
143	5	17	\N	\N
144	5	11	\N	\N
\.


--
-- Name: mrol_mods_id_rol_mod_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mrol_mods_id_rol_mod_seq', 144, true);


--
-- Data for Name: mrol_usus; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mrol_usus (id_rol_usu, id_tru, id_rol_tru, created_at, updated_at) FROM stdin;
1	1	1	2018-05-29 12:40:17	2018-05-29 12:40:17
2	1	2	2018-05-29 12:40:17	2018-05-29 12:40:17
3	1	3	2018-05-29 12:40:17	2018-05-29 12:40:17
4	1	4	2018-05-29 12:40:17	2018-05-29 12:40:17
5	1	5	2018-05-29 12:40:17	2018-05-29 12:40:17
6	2	5	2018-05-29 12:40:17	2018-05-29 12:40:17
7	4	1	\N	\N
8	4	4	\N	\N
9	4	5	\N	\N
10	5	4	\N	\N
\.


--
-- Name: mrol_usus_id_rol_usu_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mrol_usus_id_rol_usu_seq', 10, true);


--
-- Data for Name: mrols; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mrols (id_rol, nom_rol, created_at, updated_at) FROM stdin;
1	Administrador	2018-05-29 12:40:17	2018-05-29 12:40:17
2	Coord Departamento	2018-05-29 12:40:17	2018-05-29 12:40:17
3	Asis Administrativo	2018-05-29 12:40:17	2018-05-29 12:40:17
4	Docente	2018-05-29 12:40:17	2018-05-29 12:40:17
5	Coordinador	2018-05-29 12:40:17	2018-05-29 12:40:17
\.


--
-- Name: mrols_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('mrols_id_rol_seq', 5, true);


--
-- Data for Name: msec_ests; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY msec_ests (id_sec_est, id_master, ci_est_tes, created_at, updated_at) FROM stdin;
1	1	2222222	\N	\N
2	1	3333111	\N	\N
3	1	24333111	\N	\N
4	1	25333111	\N	\N
5	1	26333111	\N	\N
6	7	2222222	\N	\N
7	7	3333111	\N	\N
8	7	24333111	\N	\N
9	7	25333111	\N	\N
10	7	26333111	\N	\N
\.


--
-- Name: msec_ests_id_sec_est_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('msec_ests_id_sec_est_seq', 10, true);


--
-- Data for Name: mseccions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY mseccions (cod_sec, turno, trayecto, created_at, updated_at) FROM stdin;
NULL	Master	0	2018-05-29 12:40:17	2018-05-29 12:40:17
IN0001	Mañana	0	2018-05-29 12:46:32	2018-05-29 12:46:32
IN2222	Mañana	2	2018-05-29 12:46:58	2018-05-29 12:46:58
IN1111	Mañana	1	2018-05-29 12:47:39	2018-05-29 12:47:39
IN3121	Mañana	3	2018-05-29 12:47:53	2018-05-29 12:47:53
IN4121	Mañana	4	2018-05-29 12:48:03	2018-05-29 12:48:03
\.


--
-- Data for Name: muni_crrs; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY muni_crrs (cod_uc_pnf, cod_uc_nac, creditos, nom_uc, trayecto, hta, htt, hte, periodo, cod_pen_uc, created_at, updated_at) FROM stdin;
MAT11	MAT11	30	MATEMATICA 1	0	22	22	22	t	1	2018-05-29 12:43:47	2018-05-29 12:43:47
PROG111	PROG111	20	PROGRAMACION 1	1	30	30	30	t	1	2018-05-29 12:44:28	2018-05-29 12:44:28
PROG22	PROG22	20	PROGRAMACION 2	2	20	20	20	t	1	2018-05-29 12:45:00	2018-05-29 12:45:00
MOD22	MOD22	30	MODELADO DE BD	3	40	40	40	t	1	2018-05-29 12:45:40	2018-05-29 12:45:40
AUDIT44	AUDIT44	67	AUDITORIA	4	40	89	86	t	1	2018-05-29 12:46:13	2018-05-29 12:46:13
\.


--
-- Data for Name: password_resets; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY password_resets (email, token, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY users (id, ci_usu, name, ape_usu, img_perfil, email, password, tlf, status, remember_token, created_at, updated_at) FROM stdin;
2	87654321	ganeshadevteam	|	1491785651_index.jpeg	admin@noreply.com	$2y$10$Xlp9FB3TiQCO354lFgj11One9txORYccdUhdIQl5cR35fh9FNfuy6	686257934	t	\N	2018-05-29 12:40:17	2018-05-29 12:40:17
3	NULLUSER	ganeshadevteam	|	1491785651_index.jpeg	null@noreply.com	$2y$10$i8CJo7aOwZG6U5og6NJTYeJEgPddtS0Ljq1C/C12rtTKWxJZePyx2	784877652	t	\N	2018-05-29 12:40:17	2018-05-29 12:40:17
1	00000420	ganeshadevteam	puta	1527597636_1527081500_logoss.jpg	ganeshadevteam@gmail.com	$2y$10$Hg00dLL0D5ak21700I5pjedrO3ti1mo91sL9v.iGrC2Yi6om21Eoy	137960556	t	J6FqVPTFD23vppu9eLBqeAs46YB8ANeRN1V60QfWphdqpYvD7ZlSlOGvX8cV	2018-05-29 12:40:16	2018-05-29 12:53:23
5	22181550	Enyer	Freitez	1527600640_Selección_047.png	enyerfreitez@gmail.com	$2y$10$fwbLgKsUdtGQPBJlz6AiguFFxs5579OzWSF2O.ejNsfZru8SmX1yK	04265532495	f	FvjJXaKMtfiew09wDCgRclxfbTfDLN1GIyVoMjiotzIOFO0CWklPQL40dvM5	2018-05-29 13:30:40	2018-05-29 17:07:01
4	00000000	admin	tester	1527598782_1527081500_logoss.jpg	jesusjclark@gmail.com	$2y$10$W.lJEhv1ybYZsjEBUO2xKuCC1S/eBCO7u7JD4r5qfp8Qh3MKpka9u	04263536247	t	T0Ve1BwBqT7mDrh6O39XUkFfQoE2rCxoyvYPFrpgDXgaiPj1VnDH05z32Ly5	2018-05-29 12:49:58	2018-05-31 03:44:41
\.


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('users_id_seq', 5, true);


--
-- Name: bitacoras bitacoras_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY bitacoras
    ADD CONSTRAINT bitacoras_pkey PRIMARY KEY (id_bitacora);


--
-- Name: mejes mejes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mejes
    ADD CONSTRAINT mejes_pkey PRIMARY KEY (cod_eje);


--
-- Name: mejes_ucs mejes_ucs_cod_uc_ejes_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mejes_ucs
    ADD CONSTRAINT mejes_ucs_cod_uc_ejes_unique UNIQUE (cod_uc_ejes);


--
-- Name: mejes_ucs mejes_ucs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mejes_ucs
    ADD CONSTRAINT mejes_ucs_pkey PRIMARY KEY (cod_uc_ejes);


--
-- Name: mestudiantes mestudiantes_ci_est_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mestudiantes
    ADD CONSTRAINT mestudiantes_ci_est_unique UNIQUE (ci_est);


--
-- Name: mestudiantes mestudiantes_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mestudiantes
    ADD CONSTRAINT mestudiantes_pkey PRIMARY KEY (ci_est);


--
-- Name: mevaluacions mevaluacions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mevaluacions
    ADD CONSTRAINT mevaluacions_pkey PRIMARY KEY (id_eva);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: minstrumentos minstrumentos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY minstrumentos
    ADD CONSTRAINT minstrumentos_pkey PRIMARY KEY (id_inst);


--
-- Name: mmodulos mmodulos_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mmodulos
    ADD CONSTRAINT mmodulos_pkey PRIMARY KEY (id_mod);


--
-- Name: mnotas mnotas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mnotas
    ADD CONSTRAINT mnotas_pkey PRIMARY KEY (id_nota);


--
-- Name: mpensums mpensums_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpensums
    ADD CONSTRAINT mpensums_pkey PRIMARY KEY (cod_pen);


--
-- Name: mplan_evas mplan_evas_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mplan_evas
    ADD CONSTRAINT mplan_evas_pkey PRIMARY KEY (id_plan);


--
-- Name: mpnfs mpnfs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpnfs
    ADD CONSTRAINT mpnfs_pkey PRIMARY KEY (cod_pnf);


--
-- Name: mpuentemasters mpuentemasters_id_uc_sec_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpuentemasters
    ADD CONSTRAINT mpuentemasters_id_uc_sec_unique UNIQUE (id_uc_sec);


--
-- Name: mpuentemasters mpuentemasters_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpuentemasters
    ADD CONSTRAINT mpuentemasters_pkey PRIMARY KEY (id_uc_sec);


--
-- Name: mrol_mods mrol_mods_id_rol_mod_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_mods
    ADD CONSTRAINT mrol_mods_id_rol_mod_unique UNIQUE (id_rol_mod);


--
-- Name: mrol_mods mrol_mods_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_mods
    ADD CONSTRAINT mrol_mods_pkey PRIMARY KEY (id_rol_mod);


--
-- Name: mrol_usus mrol_usus_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_usus
    ADD CONSTRAINT mrol_usus_pkey PRIMARY KEY (id_rol_usu);


--
-- Name: mrols mrols_id_rol_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrols
    ADD CONSTRAINT mrols_id_rol_unique UNIQUE (id_rol);


--
-- Name: mrols mrols_nom_rol_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrols
    ADD CONSTRAINT mrols_nom_rol_unique UNIQUE (nom_rol);


--
-- Name: mrols mrols_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrols
    ADD CONSTRAINT mrols_pkey PRIMARY KEY (id_rol);


--
-- Name: msec_ests msec_ests_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY msec_ests
    ADD CONSTRAINT msec_ests_pkey PRIMARY KEY (id_sec_est);


--
-- Name: mseccions mseccions_cod_sec_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mseccions
    ADD CONSTRAINT mseccions_cod_sec_unique UNIQUE (cod_sec);


--
-- Name: mseccions mseccions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mseccions
    ADD CONSTRAINT mseccions_pkey PRIMARY KEY (cod_sec);


--
-- Name: muni_crrs muni_crrs_cod_uc_pnf_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY muni_crrs
    ADD CONSTRAINT muni_crrs_cod_uc_pnf_unique UNIQUE (cod_uc_pnf);


--
-- Name: muni_crrs muni_crrs_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY muni_crrs
    ADD CONSTRAINT muni_crrs_pkey PRIMARY KEY (cod_uc_pnf);


--
-- Name: users users_ci_usu_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_ci_usu_unique UNIQUE (ci_usu);


--
-- Name: users users_email_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_email_unique UNIQUE (email);


--
-- Name: users users_password_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_password_unique UNIQUE (password);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: password_resets_email_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_resets_email_index ON password_resets USING btree (email);


--
-- Name: password_resets_token_index; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX password_resets_token_index ON password_resets USING btree (token);


--
-- Name: mejes_ucs mejes_ucs_cod_ejes_euc_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mejes_ucs
    ADD CONSTRAINT mejes_ucs_cod_ejes_euc_foreign FOREIGN KEY (cod_ejes_euc) REFERENCES mejes(cod_eje) ON DELETE CASCADE;


--
-- Name: mejes_ucs mejes_ucs_cod_uc_pnf_euc_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mejes_ucs
    ADD CONSTRAINT mejes_ucs_cod_uc_pnf_euc_foreign FOREIGN KEY (cod_uc_pnf_euc) REFERENCES muni_crrs(cod_uc_pnf) ON DELETE CASCADE;


--
-- Name: mevaluacions mevaluacions_id_inst_eva_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mevaluacions
    ADD CONSTRAINT mevaluacions_id_inst_eva_foreign FOREIGN KEY (id_inst_eva) REFERENCES minstrumentos(id_inst) ON DELETE CASCADE;


--
-- Name: mevaluacions mevaluacions_id_plan_eva_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mevaluacions
    ADD CONSTRAINT mevaluacions_id_plan_eva_foreign FOREIGN KEY (id_plan_eva) REFERENCES mplan_evas(id_plan) ON DELETE CASCADE;


--
-- Name: mnotas mnotas_id_eva_not_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mnotas
    ADD CONSTRAINT mnotas_id_eva_not_foreign FOREIGN KEY (id_eva_not) REFERENCES mevaluacions(id_eva) ON DELETE CASCADE;


--
-- Name: mpensums mpensums_cod_pnf_p_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpensums
    ADD CONSTRAINT mpensums_cod_pnf_p_foreign FOREIGN KEY (cod_pnf_p) REFERENCES mpnfs(cod_pnf) ON DELETE CASCADE;


--
-- Name: mplan_evas mplan_evas_cod_sec_plan_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mplan_evas
    ADD CONSTRAINT mplan_evas_cod_sec_plan_foreign FOREIGN KEY (cod_sec_plan) REFERENCES mpuentemasters(id_uc_sec) ON DELETE CASCADE;


--
-- Name: mpuentemasters mpuentemasters_cod_seccion_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpuentemasters
    ADD CONSTRAINT mpuentemasters_cod_seccion_foreign FOREIGN KEY (cod_seccion) REFERENCES mseccions(cod_sec) ON DELETE CASCADE;


--
-- Name: mpuentemasters mpuentemasters_cod_unidad_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpuentemasters
    ADD CONSTRAINT mpuentemasters_cod_unidad_foreign FOREIGN KEY (cod_unidad) REFERENCES muni_crrs(cod_uc_pnf) ON DELETE CASCADE;


--
-- Name: mpuentemasters mpuentemasters_id_usu_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mpuentemasters
    ADD CONSTRAINT mpuentemasters_id_usu_foreign FOREIGN KEY (id_usu) REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: mrol_mods mrol_mods_id_mod_trm_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_mods
    ADD CONSTRAINT mrol_mods_id_mod_trm_foreign FOREIGN KEY (id_mod_trm) REFERENCES mmodulos(id_mod) ON DELETE CASCADE;


--
-- Name: mrol_mods mrol_mods_id_rol_trm_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_mods
    ADD CONSTRAINT mrol_mods_id_rol_trm_foreign FOREIGN KEY (id_rol_trm) REFERENCES mrols(id_rol) ON DELETE CASCADE;


--
-- Name: mrol_usus mrol_usus_id_rol_tru_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_usus
    ADD CONSTRAINT mrol_usus_id_rol_tru_foreign FOREIGN KEY (id_rol_tru) REFERENCES mrols(id_rol) ON DELETE CASCADE;


--
-- Name: mrol_usus mrol_usus_id_tru_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY mrol_usus
    ADD CONSTRAINT mrol_usus_id_tru_foreign FOREIGN KEY (id_tru) REFERENCES users(id) ON DELETE CASCADE;


--
-- Name: msec_ests msec_ests_ci_est_tes_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY msec_ests
    ADD CONSTRAINT msec_ests_ci_est_tes_foreign FOREIGN KEY (ci_est_tes) REFERENCES mestudiantes(ci_est) ON DELETE CASCADE;


--
-- Name: msec_ests msec_ests_id_master_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY msec_ests
    ADD CONSTRAINT msec_ests_id_master_foreign FOREIGN KEY (id_master) REFERENCES mpuentemasters(id_uc_sec) ON DELETE CASCADE;


--
-- Name: muni_crrs muni_crrs_cod_pen_uc_foreign; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY muni_crrs
    ADD CONSTRAINT muni_crrs_cod_pen_uc_foreign FOREIGN KEY (cod_pen_uc) REFERENCES mpensums(cod_pen) ON DELETE CASCADE;


--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: postgres
--

GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

